for i in range(65,91):
  for j in range(65,i + 1):

for k in range(1,6):
  for l in range(1,k + 1):
    print("*",end = " ")
  print()
  
for i in range(6,0,-1):
  for j in range(1,i - 1):
    print("*",end = " ")
  print()