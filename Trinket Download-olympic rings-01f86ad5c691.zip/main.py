import turtle

t = turtle.Turtle()

t.color("blue")
t.penup()
t.goto(-120, 0)
t.pendown()
t.circle(50)

t.color("black")
t.penup()
t.goto(0, 0)
t.pendown()
t.circle(50)

t.color("red")
t.penup()
t.goto(120, 0)
t.pendown()
t.circle(50)

t.color("yellow")
t.penup()
t.goto(-60, -60)
t.pendown()
t.circle(50)

t.color("green")
t.penup()
t.goto(60, -60)
t.pendown()
t.circle(50)

