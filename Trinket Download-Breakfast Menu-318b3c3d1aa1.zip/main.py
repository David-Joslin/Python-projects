day = input("What day is today? ").lower()
if day == "monday" :
  print("Cereal and orange juice")
  
elif day == "tuesday" :
  print("Noodles and coke")
  
elif day == "wednesday":
  print("Oats and milk")
  
elif day == "thursday":
  print("Idli and sambar")
  
elif day == "friday":
  print("dosa and chutney")
  
elif day == "saturday":
  print("Tea and toast")
  
elif day == "sunday":
  print("Chicken salad")
  
else:
  print("Enter the day correctly")