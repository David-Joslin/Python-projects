import turtle as t

s = t.Screen()
s.bgcolor("midnightblue")

pen = t.Turtle()
pen.hideturtle()
pen.speed(0)

def building(x):
  pen.penup()
  pen.goto(x, -120) 
  pen.pendown()
  pen.color("gray20")
  pen.begin_fill()
  for _ in range(2):
    pen.forward(80)
    pen.left(90)
    pen.forward(200)
    pen.left(90)
  pen.end_fill()
  # windows
  pen.color("gold")
  for wx in range(x+10, x+70, 20):
    for wy in range(-100, 60, 50): 
      pen.penup()
      pen.goto(wx, wy)
      pen.pendown()
      pen.begin_fill()
      for _ in range(4):
        pen.forward(10)
        pen.left(90)
      pen.end_fill()

def moon():
  pen.penup()
  pen.goto(150, 150)
  pen.pendown()
  pen.color("lightyellow")
  pen.begin_fill()
  pen.circle(40)
  pen.end_fill()

def road():
  pen.penup()
  pen.goto(-400, -200)
  pen.pendown()
  pen.color("dimgray")
  pen.begin_fill()
  for _ in range(2):
    pen.forward(800)
    pen.left(90)
    pen.forward(80)
    pen.left(90)
  pen.end_fill()
  # road lines
  pen.penup()
  pen.color("white")
  pen.pensize(3)
  pen.goto(-380, -160)
  pen.setheading(0)
  for a in range(20):
    pen.pendown()
    pen.forward(20)
    pen.penup()
    pen.forward(20)

road()
moon()

x = -350
for _ in range(8):
  building(x)
  x += 90

