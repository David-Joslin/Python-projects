# goto(x,y) . bgcolor(color) , up() -built-in functions 

# USER DEFINED FUNCTIONS - python functions

# saves time , REUSABILITY , organized

# def name():
#   # body 


# SQUARE 
import turtle
pen = turtle.Turtle()

# parameters
def square(x,y,clr):
  pen.fillcolor(clr)
  pen.begin_fill()
  pen.up()
  pen.goto(x,y)
  pen.down()
  for i in range(4):
    pen.forward(100)
    pen.right(90)
  pen.end_fill()


# call the function 
square(50,50,"yellow")

square(100,100,"blue")


